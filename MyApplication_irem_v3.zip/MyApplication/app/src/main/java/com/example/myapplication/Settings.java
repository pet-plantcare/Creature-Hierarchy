package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Settings  extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        //Alarm settings button
        Button setAlarms = (Button) findViewById(R.id.btnAlarmSettings);

        setAlarms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Settings.this, AlarmSettings.class );
                startActivity(intent);
            }
        });

        //BackyardSettings
        Button backyardSettings = (Button) findViewById(R.id.btnBackyardSettings);

        backyardSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Settings.this, BackyardSettings.class );
                startActivity(intent);
            }
        });

        Button changeTheme = (Button) findViewById(R.id.btnChangeTheme);

        changeTheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Settings.this, ChangeTheme.class );
                startActivity(intent);
            }
        });

        Button manage = (Button) findViewById(R.id.btnManagePets);

        manage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Settings.this, ManagePets.class );
                startActivity(intent);
            }
        });
    }
}