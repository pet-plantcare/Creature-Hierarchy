package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.*;

import android.view.*;
import android.widget.*;
import android.content.*;

public class Help extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        TextView text = (TextView) findViewById(R.id.textView3);
        text.setText("Help");
    }



}
