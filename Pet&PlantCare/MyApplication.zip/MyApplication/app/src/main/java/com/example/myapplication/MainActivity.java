package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.*;

import android.view.*;
import android.widget.*;
import android.content.*;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void buttonOnClick(View v) {
        Button button = (Button) v;
        startActivity(new Intent(getApplicationContext(), AddAnimal.class));

    }

    public void buttonOnClick2(View v) {
        Button button = (Button) v;
        startActivity(new Intent(getApplicationContext(), Gallery.class));

    }
}
