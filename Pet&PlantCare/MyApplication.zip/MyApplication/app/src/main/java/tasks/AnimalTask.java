package tasks;
import creature.*;
/**
 * creates tasks related to animals
 * @author Onur Oruç
 * @date 19.04.2019
 */

public class AnimalTask extends Task {

    //properties
    public static final int CUSTOM_ANIMAL  = -1;
    public static final int FOOD           = 0;
    public static final int VACCINATION    = 1;
    public static final int MEDICATION     = 2;
    public static final int HYGIENE        = 3;
    public static final int NAILS          = 4;
    public static final int WATER_ANIMAL   = 5;
    public static final int WALKING        = 6;
    public static final int WATER_CLEANING = 7;

    //constructor
    public AnimalTask(Creature creature , int taskType) //bundan pek emin değilim... :D ama şimdilik compile oldu
    {
        super( creature , taskType );
    }

    //methods

}





